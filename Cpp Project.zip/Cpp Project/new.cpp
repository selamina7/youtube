#include<iostream> // change from constream.h 
#include"file1.cpp" 

 
using namespace std; 
 
int main() 
{ 
   cout<<sum(10,20); 

   return 0; 
}
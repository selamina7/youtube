#include<iostream>
#include<fstream>
#include "studentl.h"


class Admin

{

int roll[5];
int marks[5];
string name[5];

public:
void getdata ();
void sdisplay ();
} ;

void admin :: getdata ()
{
   int temp=0;
ofstream out;
out.open("notepad.txt");
   for(int i=0; i<5; i++)
{
cout<<"Enter name: "<<endl;
cin>>name[i] ;

cout<<"Enter nos: "<<endl;
cin>>roll[i] ;

cout<<"Enter marks in subject: "<<endl;
cin>>marks[i] ;

out<<"Enter name: "<<endl;
out<<name[i] <<endl;

out<<"Enter nos: "<<endl;
out<<roll[i] <<endl;
out<<"Enter marks in subject: "<<endl;
out<<marks[i]<<endl ;
}
/*ofstream textpad("notepad.txt");
     //ofstream is for writing data | ifstream for reading
textpad << roll << endl;
  textpad << marks << endl;
                 //this is pretty much similar to cout <<
textpad.close();                          //close it


}


/*void student :: sdisplay()
{
cout<<"Enter your no=="<<endl;
cin>>roll[i];
cout<<"result:"<<marks[i];
}*/
}
int main()
{
admin stu;
stu.getdata() ;
student a;
a.getStudent();  
//stu.sdisplay() ;
return 0;
}

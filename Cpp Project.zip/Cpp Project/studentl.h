

#include "project.cpp"
class student
{
void getStudent()
{
    int i;

myfile.open("text.txt" ios::in);


   std::cout << "Enter your no="<<endl;
    std::cin >>roll[i];
   

     if(roll[i] ==roll[1])
    std::cout<<"your name="<<name[1];
    std::cout<<"your roll="<<roll[1];
    std::cout<<"your mark="<<mark[1];

    else if(roll[i] ==roll[2])
    std::cout<<"your name="<<name[2];
    std::cout<<"your roll="<<roll[2];
    std::cout<<"your mark="<<mark[2];

    else if(roll[i] ==roll[3])
    std::cout<<"your name="<<name[3];
    std::cout<<"your roll="<<roll[3];
    std::cout<<"your mark="<<mark[3];

    else if(roll[i] ==roll[4])
    std::cout<<"your name="<<name[4];
    std::cout<<"your roll="<<roll[4];
    std::cout<<"your mark="<<mark[4];

    else if(roll[i] ==roll[5])
    std::cout<<"your name="<<name[5];
    std::cout<<"your roll="<<roll[5];
    std::cout<<"your mark="<<mark[5];

    else if(roll[i] ==roll[6])
   std:: cout<<"your name="<<name[6];
   std:: cout<<"your roll="<<roll[6];
   std:: cout<<"your mark="<<mark[6];

    else if(roll[i] ==roll[7])
    std::cout<<"your name="<<name[7];
    std::cout<<"your roll="<<roll[7];
    std::cout<<"your mark="<<mark[7];

    else if(roll[i] ==roll[8])
   std:: cout<<"your name="<<name[8];
   std:: cout<<"your roll="<<roll[8];
   std:: cout<<"your mark="<<mark[8];

    else if(roll[i] ==roll[9])
   std:: cout<<"your name="<<name[9];
   std:: cout<<"your roll="<<roll[9];
   std:: cout<<"your mark="<<mark[9];

    else if(roll[i] ==roll[10])
  std::  cout<<"your name="<<name[10];
  std::  cout<<"your roll="<<roll[10];
  std::  cout<<"your mark="<<mark[10];
}

};
